/*
 * 
 */
package app.martin;

/**
 *
 * @author Priyanka Kotnis
 */
public interface ActionAlias {
    public void execute();
}
